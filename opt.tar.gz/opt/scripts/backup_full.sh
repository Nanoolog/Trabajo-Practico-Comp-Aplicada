#!/bin/bash

if [ "$1" = "-help" ]; then
 echo "Uso: backup_full.sh ORIGEN DESTINO"
 exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
 echo "Origen inexistente"
 exit 1
fi

if [ ! -d "$DESTINO" ]; then
 echo "Destino inexistente"
 exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

echo "Backup realizado"
