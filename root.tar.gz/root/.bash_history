 poweroff
 poweroff
hostnamectl set-hostname TPServer
hostname
clear
cat /etc/debian_version
cat /etc/os-realease
cat /etc/os-release
ping c 4 8.8.8.8
ping -c 4 8.8.8.8
clear
apt full-upgrade -y
cat /etc/debian_version
sudo update 
apt update
sudo apt update
clear
sudo apt update
clear
apt update
dhcLient
clear
ping -c 3 google.com
apt update
clear
nano /etc/resolv.conf
nano /etc/resolv.conf
vi /etc/resolv.conf
:wq
clear
apt update
apt full-upgrade -y
cat /etc/apt/sources.list
clear
cat /etc/apt/sources.list
clear
echo -e "deb https://deb.debian.org/debian bookworm man\ndeb hhtps_//deb.debian.org//debian bookworm-updates main\ndeb http://security.debian.org/debian-security bookworm-security main" > /etc/apt/sources.list
apt-get update
echo -e "deb http://deb.debian.org/debian bookworm man\ndeb http://deb.debian.org//debian bookworm-updates main\ndeb http://security.debian.org/debian-security bookworm-security main" > /etc/apt/sources.list
apt-get update
apt-get dist-upgrade -y
cat /etc/debian_version
clear
apt update
apt install openssh-server
clear
apt install openssh-server
hostnamectl set-hostname TPServer
hostname
apt install openssh-server -y
apt-get install -f -y
apt-get dist-upgrade -y
apt-get dist-upgrade -y
clear
apt-get dist-upgrade -y
apt install openssh-server -y
apt-get clean
apt-get autoremove -y
clear
dpkg --purge openssh-client
dpkg --purge --force-depends openssh-client sshfs
apt-get install -f -y
apt-get dist-upgrade -y
clear
apt-get install openssh-server openssh-client -y
dpkg --configure -a
apt-get dist-upgrade --fix-broken -y
apt-get install openssh-server -y
apt update
clear
tu viejha
clear
apt-get install lsmod |grep vbox
apt-get install lsmod | grep vbox
clear
systemctl start ssh
apt-get cat etc/debian_version
cat etc/debian_version
cat etc/debian_version
apt-get clean
apt-get clear
apt-get clean
clear
apt-get autoremove -y
apt-get install -f -y
apt-get install openssh-server -y
dpkg -i --force-depends /var/cache/apt/archives/openssh-*.deb
clear
cat /etc/debian_version
cat /etc/os-release
cat /etc/apt/sources.list
echo "nameserver 8.8.8.8" > /etc/resolv.conf
apt_get clean
apt-get clean
apt-get autoremove -y
apt-get update
cat /etc/debian_version
apt-get dist-upgrade -y
clear
echo -e "deb http://deb.debian.org/debian bookworm main\ndeb http://deb.debian.org//debian bookworm-updates main\ndeb http://security.debian.org/debian-security bookworm-security main" > /etc/apt/sources.list
apt-get update
cat /etc/debian_version
apt-get dist-upgrade -y
cat /etc/debian_version
clear
cat /etc/debian_version
cat /etc/os-release
sed -i 's/#APermitRootLogin prohibit-password/PermitRootLogin prohibit-password/' /etc/ssh_config
apt-get install openssh-server -y
systemctl enable ssh
systemctl status ssh
clear
hostname -I
hostnamectl set-hostname TPServer
exec bash
scp db root@192.168.1.47:/root/
dir
clear
dir
clear
whoami
clear

ip route
clear
hostname -I
apt update
apt install apache 2 php libapache2-mod-php -y
apt install apache2 php libapache2-mod-php -y
ping -I
hostname -I
clear
system status apache2
systemctl status apache2
systemctl enable apache2
ss -tulpn | grep :80
ls -la /tmp
clear
ls -la /tmp
cp /tmp/index.php /var/www/html/index.php
ls -la /var/www/html
hostname -I
clear
apt install mariadb-server -y
systemctl enable mariadb
systemctl start mariadb
clear
systemctl start mariadb
systemctl enable mariadb
clear
systemctl enable mariadb
sysclear
clear
systemctl start mariadb
systemctl enable mariadb
clear
systemctl status mariadb
ls /root
clear
ls /root
clear
mysql < /root/db.sql
ls -la 7root
clear
ls -la /root
ls /media
mount | grep vbox
ip a
clear
ipo
ip a
inet 192.168.x.x/24
grep PermitRootLOgin /etc/ssh/sshd_config
cat /etc/ssh/sshd_config | grep PermitRootLogin
apt-get install nano
clear
nano /etc/ssh/sshd_config
systmctl restart ssh
systemctl restart ssh
clear
systemctl restart ssh
clear
grep PermitRootLogin /etc/ssh/sshd_config
systemctl restart ssh
ls /root
clear
ls /root
mysql < /root/db.sql
mysql
clear
mv /tmp/index.php /var/www/html/index.php
clear
ls -la /var/www/html
systemctl restart apache2
systemctl status apache2
cat /etc/apache2/mods-enabled/dir.conf
mv /var/www/gtml/index.html /var/www/html/index.html.bak
clear
systemctl restar apache2
systemctl restart apache2
clear
hostname -I
clear
cat /etc/network/Interfaces
cat /etc/network/interfaces
ip route
default via 192.168.1.1
iface enp0s3 inet dhcp
clear
ip route
nano /etc/network/interfaces
systemctl restart networking
clear
nano /etc/network/interfaces
clear
lsblk
clear
fdisk -l
fdisk /dev/sdb
clear
fdisk /dev/sdb
cñear
clear
fsidk -l /dev/sdb
fdisk -l /dev/sdb
fdisk /dev/sdb
clear
fdisk
fdisk /dev/sdb
clear
fdisk /dev/sdb
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
fdisk -l /dev/dsb
fdisk -l /dev/sdb
lsblk
fdisk -l /dev/sdb
lsblk
clear
 fdisk /dev/sdb
clear
fdisk /dev/sdb
reboot
clear
lsblk
clear
mkfs.ext4 /dev/sdc1
clear
cp /reboot/index.php /www_dir/
ls /rooot
ls /root
clear
ls /root
cp /root/index.php /www_dir/
ls -ld /www_dir
ls /
ls -l /
mkdir /www_dir
mkdir /backup_dir
ls =ld /www_dir /baclup_dir
ls -ld /www_dir /baclup_dir
ls -ld /www_dir /backup_dir
clear
mount /dev/sdb1 /www_dir
clear
cp /root/index.php /www_dir/
ls /www_dir
clear
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
clear
systemctl status apache 2
systemctl status apache2
clear
systemctl start apache2
clear
cat /etc/fstab
mount -o remount,rw /
nano /etc/fstab
clear
cat /etc/fstab
ip route
clear
ip a
hostname /I
hostname -I
systemctl status ssh
cat /etc/fstab
nano /etc/fstab
clear
reboot
